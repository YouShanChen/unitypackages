using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyTest : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if ( Input.GetKey(KeyCode.U)) {  transform.Translate( 0, 0, 1f ); Debug.Log('U'); }
        else if(Input.GetKey(KeyCode.J)){  transform.Translate( 0, 0, -1f );  }
        else if(Input.GetKey(KeyCode.K)){  transform.Translate( 1f, 0, 0 );  }
        else if(Input.GetKey(KeyCode.H)){  transform.Translate( -1f, 0, 0 );  }
    }
}
