using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraInitializer : MonoBehaviour
{
    // Start is called before the first frame update
    public Vector3 initialPosition;
    public Quaternion initialRotation;

    void Awake()
    {
        initialPosition=transform.position;
        initialRotation=transform.rotation;
    }
    void ResetCamera()
    {
        transform.position=initialPosition;
        transform.rotation=initialRotation;
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
