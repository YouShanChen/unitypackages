using UnityEngine.AI;
using UnityEngine;
using Unity.VisualScripting;

public class enemyAi : MonoBehaviour{
public GameObject player; //���a���
public Vector3 patrolDestPoint; //�C���ؼ��I
public Transform m_transform; 
public Animator m_animator;
public NavMeshAgent m_agent;

private Vector3 initialPosition; //���I
public float wanderRadius=15; //�C���b�|
public float defendRadius=30; //�۽åb�|
public float chaseRadius = 60; //�l���b�|
public float attackRange = 0.5f; //�����Z��
private float distanceToPlayer; //�P���a�Z��
private float distanceToInitial; //�P���I�Z��
private float timeBetweenAttack = 3; //�������j
private float lastAttackTime;//�̪�@�������ɶ�
private float hideTime;//���îɶ�
private int power=30;//�Ǫ������O
private bool is_Running = false; //�O�_�b�]
private bool is_Attacking = false; //�O�_�b����
private bool is_Counting = false; //�O�_�b�p��
float m_walkSpeed = 1f; //�����t��
float m_runSpeed = 1f; //�b�]�t��


private enum MonsterState //�Ǫ����A
    {
        WALK,
        CHASE,
        ATTACK,
        RETURN
    }
private MonsterState currentState = MonsterState.WALK;
private void OnDrawGizmosSelected()//�e�X�d��
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, wanderRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, defendRadius);
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, chaseRadius);

    }

    void Start () {
        player = GameObject.Find("Player");
        m_animator = this.GetComponent<Animator>();
        m_transform = this.transform;
        m_agent= GetComponent<NavMeshAgent>();
        initialPosition = this.GetComponent<Transform>().position;
        wanderRadius = Mathf.Min(chaseRadius, wanderRadius);//�C���b�|���j��l���b�|
        patrolDestPoint = GetNewPatrolDestPoint();//���ͷs���C���I
    }
 void Update()
    {
        switch (currentState)
        {
            case MonsterState.WALK://����
                if (is_Running)
                {
                    m_animator.SetBool("isrun", false);
                    is_Running = false;
                }
                if (Vector3.Distance(patrolDestPoint, m_transform.position) <= m_agent.stoppingDistance)
                {
                    patrolDestPoint = GetNewPatrolDestPoint();
                }
                else
                {
                    m_agent.SetDestination(patrolDestPoint);
                    WalkTo();
                }
                WanderRadiusCheck();
                break;
            case MonsterState.CHASE://�l��
                if (!is_Running)
                {
                    m_animator.SetBool("isrun", true);
                    is_Running = true;
                }
                if (is_Attacking)
                {
                    m_animator.SetBool("isAttacking", false);
                    is_Attacking = false;
                }
                m_agent.SetDestination(player.transform.position);
                RunTo();
                ChaseRadiusCheck();
                break;
            case MonsterState.ATTACK://����
                lastAttackTime = Time.time;
                if (!is_Attacking)
                {
                    m_animator.SetBool("isAttacking", true);
                    is_Attacking = true;
                }
                m_agent.SetDestination(player.transform.position);
                Debug.Log("Attack");
                FindObjectOfType<PlayerHealth>().TakeDamage(power);
                AttackCheck();
                break;
            case MonsterState.RETURN://��^���I
                m_agent.SetDestination(initialPosition);
                RunTo();
                ReturnCheck();
                break;
        }
    }

    void WalkTo() //����
     {
        m_agent.speed = m_walkSpeed;
        float speed = m_walkSpeed * Time.deltaTime;
         m_agent.Move(m_transform.TransformDirection(new Vector3(0, 0, speed)));
     }
    void RunTo() //�b�]
    {
        m_agent.speed = m_runSpeed;
        float speed = m_runSpeed * Time.deltaTime;
        m_agent.Move(m_transform.TransformDirection(new Vector3(0, 0, speed)));
    }
    Vector3 GetNewPatrolDestPoint() //�ͦ��s���C���I
    {
        float offsetX = Random.Range(-wanderRadius, wanderRadius);
        float offsetZ = Random.Range(-wanderRadius, wanderRadius);
        Vector3 randomPoint = new Vector3(initialPosition.x + offsetX, transform.position.y, initialPosition.z + offsetZ);
        NavMeshHit hit;
        if (NavMesh.SamplePosition(randomPoint, out hit, wanderRadius, 1))
            randomPoint = hit.position;
        else
            randomPoint = transform.position;
        return randomPoint;
    }
    void WanderRadiusCheck() //�C�����A�˴�
    {
        distanceToPlayer = Vector3.Distance(player.transform.position, m_transform.position);
        distanceToInitial = Vector3.Distance(m_transform.position, initialPosition);
        is_Running = false;
        m_animator.SetBool("isrun", false);
        if (distanceToPlayer <defendRadius && !PlayerHealth.isDead)
        {
            currentState = MonsterState.CHASE;
        }
    }
    void ChaseRadiusCheck() //�l�����A�˴�
    {
        distanceToPlayer = Vector3.Distance(player.transform.position, m_transform.position);
        distanceToInitial = Vector3.Distance(m_transform.position, initialPosition);
        is_Running = true;
        m_animator.SetBool("isrun", true);
        if (ironbox.ishiding && !(is_Counting))//�Y�b�d�l�̥B���p�ɫh�}�l�p��
        {
            hideTime = Time.time;
            is_Counting = true;
        }
        if (ironbox.ishiding && Time.time - hideTime> 10.0f)//�Y�b�d�l�̫ݶW�L�Q���h�Ǫ��|��^���I
        {
            currentState = MonsterState.RETURN;
            Debug.Log("you avoid monster");
            hideTime = Time.time;
        }
        if (!ironbox.ishiding)//�Y�b�d�l�~�h�]�����p��
        {
            is_Counting = false;
        }
        if (distanceToInitial > chaseRadius|| PlayerHealth.isDead)//���}�l���d��Ϊ��a���`�h�Ǫ��|��^���I
        {
            currentState = MonsterState.RETURN;
        }
        else if (distanceToPlayer < 8.0f && Time.time - lastAttackTime > timeBetweenAttack&& !ironbox.ishiding)//���a��Ǫ��b�@�w�Z�����B�Ǫ������N�o�����A�Ǫ��o�ʧ���
        {
            currentState = MonsterState.ATTACK;
        }
        
    }
    void AttackCheck()//�������A�˴�
    {
        distanceToPlayer = Vector3.Distance(player.transform.position, m_transform.position);
        currentState = MonsterState.CHASE;
    }
    void ReturnCheck() //��^���A�˴�
    {
        distanceToInitial = Vector3.Distance(m_transform.position, initialPosition);
        if (distanceToInitial<3.0f)
        {
            is_Running = false;
            m_animator.SetBool("isrun", false);
            currentState = MonsterState.WALK;
        }
    }
}
