using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class enemyParent : MonoBehaviour
{
    // Start is called before the first frame update
    private GameObject parent;
    private GameObject children;
    private Vector3 m_position;
    void Start()
    {
    parent=GameObject.Find("EnemyParent");
    children=GameObject.Find("Bacteria");
    }

    // Update is called once per frame
    void Update()
    {
        parent.transform.localPosition=Vector3.zero;
    }
}
