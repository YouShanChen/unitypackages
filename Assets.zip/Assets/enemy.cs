 using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class enemy : MonoBehaviour
{
    [Range(0,50)][SerializeField] float attackRange = 5, sightRange = 20, timeBetweenAttacks = 3;

    [Range(0, 20)] [SerializeField] int power;
    

    private NavMeshAgent thisenemy;
    public Transform playerPos;
    private bool isAttacking;

    private void Start()
    {
        thisenemy = GetComponent<NavMeshAgent>();
        playerPos = FindObjectOfType<PlayerHealth>().transform;
        GetComponent<Animator>().SetBool("run",false);
    } 

    private void Update()
    {
        float distanceFromPlayer = Vector3.Distance(playerPos.position, this.transform.position);

        if (distanceFromPlayer<=sightRange && distanceFromPlayer > attackRange && !PlayerHealth.isDead)
        {
            isAttacking = false;
            thisenemy.isStopped = false; 
            StopAllCoroutines();
            ChasePlayer();
        }

        if(distanceFromPlayer<=attackRange && !isAttacking &&!PlayerHealth.isDead)
        {
            thisenemy.isStopped = true;
            StartCoroutine(AttackPlayer());
        }

        if (PlayerHealth.isDead)
        {
            thisenemy.isStopped = true;
        }

    }


    private void ChasePlayer()
    {
        thisenemy.SetDestination(playerPos.position);
    }
     
    private IEnumerator AttackPlayer()
    {
        isAttacking = true;

        yield return new WaitForSeconds(timeBetweenAttacks);

        FindObjectOfType<PlayerHealth>().TakeDamage(power);

        isAttacking = false;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(this.transform.position, sightRange);

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(this.transform.position, attackRange); 
    }
}
