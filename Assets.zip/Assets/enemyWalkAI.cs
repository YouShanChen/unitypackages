using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyWalkAI : MonoBehaviour
{
 public Transform[] waypoints;
 private int num=0;
 private UnityEngine.AI.NavMeshAgent agent;
 private float timer=0f;
 private float waitTimer=3f;
    void Start()
    {
        agent=GetComponent <UnityEngine.AI.NavMeshAgent>();
    }

    void Update()
    {
        timer+=Time.deltaTime;
        if(timer<waitTimer)
        {
            num++;
            timer=0;
            num%=4;
            agent.destination=waypoints[num].position;
        }
    }
}
