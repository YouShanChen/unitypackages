using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreBoard : MonoBehaviour
{
    // Start is called before the first frame update
    //public static int score;
    //public Text WaterScore;
    void Start()
    {
        //score = 0;
        
    }

    // Update is called once per frame
    void Update()
    {
        show();

    }
    private void show()
    {
        //WaterScore.text = "Target:" + score.ToString()+"/10";
        //  ShowScore��쪺text����.��text��r = " ";
        // .ToString()�i�Nint�ରstring
    }
}
